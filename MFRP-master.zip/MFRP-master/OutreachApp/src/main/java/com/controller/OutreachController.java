package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.Admin;
import com.model.Volunteer;

@Controller
public class OutreachController {

	@Autowired
//	private UserDao userDao;

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String showPage() {

		return "home";
	}
	
	///////////   -----   Volunteer   ------   ////////////////////
	@RequestMapping(value = "/volunteerHome", method = RequestMethod.GET)
	public String showAdminPage(@ModelAttribute("volunteer") Volunteer volunteer) {
		volunteer = new Volunteer();

		return "volunteerHome";
	}

	@RequestMapping(value = "/volunteerLogin", method = RequestMethod.GET)
	public String performlogin(@ModelAttribute("volunteer") Volunteer volunteer, BindingResult result) {

		return "volunteerLogin";
	}

	@RequestMapping(value = "/volunteerRegistration", method = RequestMethod.GET)
	public String performRegistration(@ModelAttribute("volunteer") Volunteer volunteer, BindingResult result) {

		return "volunteerRegistration";
	}

	///////////   -----   Admin   ------   ////////////////////
	@RequestMapping(value = "/adminHome", method = RequestMethod.GET)
	public String showPage(@ModelAttribute("admin") Admin admin) {
		admin = new Admin();

		return "adminHome";
	}

	@RequestMapping(value = "/adminLogin", method = RequestMethod.GET)
	public String performlogin(@ModelAttribute("admin") Admin admin, BindingResult result) {

		return "adminLogin";
	}

	@RequestMapping(value = "/adminRegistration", method = RequestMethod.GET)
	public String performRegistration(@ModelAttribute("admin") Admin admin, BindingResult result) {

		return "adminRegistration";
	}

	/*
	 * @RequestMapping(value = "/register", method = RequestMethod.POST) public
	 * String registerPage(@ModelAttribute("user") User user, BindingResult result,
	 * ModelMap model) {
	 * 
	 * if (result.hasErrors()) { return "userregistration"; }
	 * 
	 * userDao.create(user); model.addAttribute("msg",
	 * "Student registration successful.");
	 * 
	 * return "index"; }
	 * 
	 * @RequestMapping(value = "/first", method = RequestMethod.POST) public String
	 * loginPage(@ModelAttribute("user") User user, BindingResult result, ModelMap
	 * model) {
	 * 
	 * if (result.hasErrors()) { return "userlogin"; }
	 * 
	 * List<User> listStudent = userDao.read(); System.out.println(listStudent);
	 * System.out.println("dfgdfgdfg"); for (User user2 : listStudent) { if
	 * (user2.getEmailId().equals(user.getEmailId()) &&
	 * user2.getPassword().equals(user.getPassword())) { return "first"; } } return
	 * "userlogin";
	 * 
	 * }
	 */
}
